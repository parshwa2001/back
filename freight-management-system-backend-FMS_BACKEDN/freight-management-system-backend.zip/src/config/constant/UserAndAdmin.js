
module.exports = Admin_TYPE = {
 superAdmin : 1 ,
 admin : 2
}

module.exports = User = {

}